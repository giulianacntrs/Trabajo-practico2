package ar.org.centro8.curso.java.entities;

import java.text.DecimalFormat;

public abstract class Vehiculo implements Comparable<Vehiculo> {
    private String marca;
    private String modelo;
    private double precio;
    private DecimalFormat df = new DecimalFormat("###,###.00");

    public Vehiculo(String marca, String modelo, double precio2) {
        this.marca = marca;
        this.modelo = modelo;
        this.precio = precio2;
    }

    @Override
    public String toString() {
        return "Marca=" + marca + "// Modelo=" + modelo;
    }

    @Override
    public int compareTo(Vehiculo para) {
        String thisVehiculo = this.getMarca() + "," + this.getModelo() + "," + this.getPrecioFormat();
        String paraVehiculo = para.getMarca() + "," + para.getModelo() + "," + para.getPrecioFormat();
        return thisVehiculo.compareTo(paraVehiculo);
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public String getPrecioFormat() {
        return df.format(getPrecio());
    }
    
}